export const SET_PLACES = "SET_PLACES";

export const TRY_AUTH = "TRY_AUTH";

export const UI_START_LOADING = "UI_START_LOADING";
export const UI_STOP_LOADING = "UI_STOP_LOADING";
