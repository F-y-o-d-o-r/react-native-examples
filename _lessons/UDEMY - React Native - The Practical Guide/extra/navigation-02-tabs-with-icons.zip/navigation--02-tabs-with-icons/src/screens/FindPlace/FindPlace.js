import React, { Component } from 'react';
import { View, Text } from 'react-native';

class FindPlaceScreen extends Component {
    render () {
        return (
            <View>
                <Text>On FindPlaceScreen</Text>
            </View>
        );
    }
}

export default FindPlaceScreen;