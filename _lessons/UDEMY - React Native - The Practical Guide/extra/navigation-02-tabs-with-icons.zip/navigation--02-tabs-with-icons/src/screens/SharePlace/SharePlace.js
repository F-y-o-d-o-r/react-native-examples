import React, { Component } from 'react';
import { View, Text } from 'react-native';

class SharePlaceScreen extends Component {
    render () {
        return (
            <View>
                <Text>On SharePlaceScreen</Text>
            </View>
        );
    }
}

export default SharePlaceScreen;